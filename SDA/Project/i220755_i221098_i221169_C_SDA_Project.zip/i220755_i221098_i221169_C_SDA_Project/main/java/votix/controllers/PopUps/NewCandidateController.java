package votix.controllers.PopUps;

import javafx.stage.Stage;

public class NewCandidateController {

    private Stage stage;

    public void setPrimaryStage(Stage stage) {
        this.stage = stage;
    }

}

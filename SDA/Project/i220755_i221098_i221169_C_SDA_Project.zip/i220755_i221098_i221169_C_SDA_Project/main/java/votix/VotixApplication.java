package votix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotixApplication {
    public static void main(String[] args) {
        SpringApplication.run(VotixApplication.class, args);
    }
}
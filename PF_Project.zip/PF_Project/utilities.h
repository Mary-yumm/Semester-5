#ifndef UTILITIES_H
#define UTILITIES_H
#include <iostream>
using namespace std;

double stringToDouble(char *str);

bool isEqual(char *str1, char *str2);

#endif
#ifndef ADMINFEATURES_H
#define ADMINFEATURES_H


void removeUser();

void addUser();

bool isEqual3(char *str1, char *str2);

void viewActivityLogs();

#endif
#ifndef SUPPORT_H
#define SUPPORT_H

#include <iostream>
#include <fstream>
using namespace std;

void giveFeedback(char *username);

void supportRequests(char *username);

void ResolveQuery();

void FeedbackResponse();

#endif